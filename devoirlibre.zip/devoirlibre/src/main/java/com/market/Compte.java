package com.market;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.Expose;

import lombok.NoArgsConstructor;
@NoArgsConstructor
public class Compte {
	@Expose
    private String numCompte;
	@Expose
    private LocalDate dateCreation;
	@Expose
    private LocalDate dateUpdate;
	@Expose
    private String devise;
    private Client client;
    private List<Transaction> transactions;
    private Banque banque;

    public Compte(Banque banque, Client client, LocalDate dateCreation, LocalDate dateUpdate, String devise, String numCompte) {
        this.banque = banque;
        this.client = client;
        this.dateCreation = dateCreation;
        this.dateUpdate = dateUpdate;
        this.devise = devise;
        this.numCompte = numCompte;
    }

    public String getNumCompte() {
        return numCompte;
    }
    public void setNumCompte(String numCompte) {
        this.numCompte = numCompte;
    }
    public LocalDate getDateCreation() {
        return dateCreation;
    }
    public void setDateCreation(String dateCreationStr) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        this.dateCreation = LocalDate.parse(dateCreationStr, formatter);
    }
    public LocalDate getDateUpdate() {
        return dateUpdate;
    }
    public void setDateUpdate(String dateUpdatestr) {
    	 DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
         this.dateUpdate = LocalDate.parse(dateUpdatestr, formatter);}
    public Client getClient() {
        return client;
    }
    public void setClient(Client client) {
        this.client = client;
    }
    public Compte() {
    }


    public String getDevise() {
        return devise;
    }

    public void setDevise(String devise) {
        this.devise = devise;
    }
    public void setTransaction(List<Transaction> tr){
       this.transactions=tr;
    }
    public List<Transaction> getTransactions(){
        return this.transactions;
    }

    public Banque getBanque() {
        return banque;
    }

    public void setBanque(Banque banque) {
        this.banque = banque;
    }
    public void ajoutetransaction(Transaction transaction){
        int i=0;
        for(Transaction tr:transactions){
            if(tr.getReference().equals(transaction.getReference())){
                i=1;
                    
            }
        }
        if(i==0){
            transactions.add(transaction);
        }
}
public void recherchetransaction(Transaction transaction){
    int i=0;
    for(Transaction tr:transactions){
        if(tr.getReference().equals(transaction.getReference())){
            i=1;

        }
        
}
if(i==1){
    
        System.out.print("transaction exist");

    
}
else{
    System.out.print("transaction doesn't exist");

}


}
public String toJson() {
	 
	        // Format dates as strings
	        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	        String dateCreationStr = dateCreation.format(formatter);
	        String dateUpdateStr = dateUpdate.format(formatter);

	        // Build JSON manually
	        return String.format(
	                "{\"numCompte\": \"%s\", \"dateCreation\": \"%s\", \"dateUpdate\": \"%s\", \"devise\": \"%s\"}",
	                numCompte, dateCreationStr, dateUpdateStr, devise);
	    }

    
}
