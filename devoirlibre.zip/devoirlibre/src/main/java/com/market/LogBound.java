package com.market;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class LogBound {
    private List<Client> clients=new ArrayList<>();

public void ajouteclient(Client client){
int i=0;
    for(Client c:clients){
        if(c.getNumClient().equals(client.getNumClient())){
           i=1;
            
        }
       
    }
    if(i==0) {
    	clients.add(client);
    }
    
}
public void rechercheclient(Client client) {
	int i=0;
    for(Client c:clients){
        if(c.getNumClient().equals(client.getNumClient())){
           i=1;
            
        }
       
    }
    if(i==0) {
    	System.out.print("client doesn't exist");
    }
    else {
    	System.out.print("client exist");
    }
}

public List<Client> getClients() {
	return clients;
}

public void setClients(List<Client> clients) {
	this.clients = clients;
}

}