package com.market;

import java.util.ArrayList;
import java.util.List;
public class Banque {
    private String id;
    private String pays;
    private final List<Compte> comptes=new ArrayList<>();

    public Banque(String id, String pays) {
        this.id = id;
        this.pays = pays;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPays() {
        return pays;
    }

    public void setPays(String pays) {
        this.pays = pays;
    }

    public List<Compte> getComptes() {
        return comptes;
    }

    public void ajoutComptes(Compte c) {
        this.comptes.add(c);
    }

}
