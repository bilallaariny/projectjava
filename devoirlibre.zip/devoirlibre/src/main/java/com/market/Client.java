package com.market;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.Expose;

import lombok.NoArgsConstructor;
@NoArgsConstructor
public class Client {
	@Expose
    private String numClient;
	@Expose
    private String nom;
	@Expose
    private String prenom;
	@Expose
    private String adresse;
	@Expose
    private String phone;
	@Expose
    private String email;
    private List<Compte> comptes=new ArrayList<>();
    
    
    public Client() {
		super();
	}
	public String getNumClient() {
        return numClient;
    }
    public String getNom() {
        return nom;
    }
    public String getPrenom() {
        return prenom;
    }
    public String getAdresse() {
        return adresse;
    }
    public String getPhone() {
        return phone;
    }
    public String getEmail() {
        return email;
    }
    public void setComptes(List<Compte>comptes){
    	this.comptes=comptes;
    }
   
    public List<Compte> getComptes() {
		return comptes;
	}
	public Client(String numClient, String nom, String prenom, String adresse, String phone, String email) {
        this.numClient = numClient;
        this.nom = nom;
        this.prenom = prenom;
        this.adresse = adresse;
        this.phone = phone;
        this.email = email;
    }
    public void setNumClient(String numClient) {
        this.numClient = numClient;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }
    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }
    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public void createcompte(Compte compte) {
    	int i=0;
    	for(Compte com:comptes) {
    		if(com.getNumCompte().equals(compte.getNumCompte())) {
    			i=1;
    		}
    	}
    	if (i==0) {
    		comptes.add(compte);
    	}
    }
    public void recherchecompte(Compte compte) {
    	int i=0;
    	for(Compte com:comptes) {
    		if(com.getNumCompte().equals(compte.getNumCompte())) {
    			i=1;
    		}
    	}
    	if (i==0) {
    		System.out.print("doesn't exist");
    	}
    	else {
    		System.out.print("compte exist");
    	}
    }
    public String toJson() {
        Gson gson = new GsonBuilder()
                .setPrettyPrinting()
                .excludeFieldsWithoutExposeAnnotation()
                .create();
        return gson.toJson(this);}


}
