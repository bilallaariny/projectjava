package com.market;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.market.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

public class testcompte {
	public static String localDateToString(LocalDate date) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd"); 
        return date.format(formatter);
    }
	@Test
	public void createcompte() {
		Compte compte=new Compte();
		compte.setNumCompte("l2");
		compte.setDateCreation("22-10-2020");
		compte.setDateUpdate("22-10-2021");
		compte.setDevise("post");
		Client client=new Client();
		List<Compte>comptes=new ArrayList<>();
		comptes.add(compte);
		client.setComptes(comptes);
		
		Compte compte1=new Compte();
		compte1.setNumCompte("l2");
		compte1.setDateCreation("22-10-2020");
		compte1.setDateUpdate("22-10-2021");
		compte1.setDevise("devise");
		
		client.createcompte(compte1);
		for(Compte c:client.getComptes()) {
		System.out.print(c.getDevise());
		}
		
	}
	@Test
public void recherchecomptetest() {
	Compte compte=new Compte();
	compte.setNumCompte("l2");
	compte.setDateCreation("22-10-2020");
	compte.setDateUpdate("22-10-2021");
	compte.setDevise("post");
	Client client=new Client();
	List<Compte>comptes=new ArrayList<>();
	comptes.add(compte);
	client.setComptes(comptes);
	
	Compte compte1=new Compte();
	compte1.setNumCompte("l2");
	compte1.setDateCreation("22-10-2020");
	compte1.setDateUpdate("22-10-2021");
	compte1.setDevise("devise");
	
	client.recherchecompte(compte1);
	
}
	@Test
	public void tojsontest() {
		
		Compte compte1=new Compte();
		compte1.setNumCompte("l2");
		compte1.setDateCreation("22-10-2020");
		compte1.setDateUpdate("22-10-2021");
		compte1.setDevise("devise");
		System.out.print(compte1.toJson());
		 LocalDate dateCreation = LocalDate.of(2020, 10, 22);
	        LocalDate dateUpdate = LocalDate.of(2021, 10, 22);

	        
	        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

	        
	        String dateCreationStr = dateCreation.format(formatter);
	        String dateUpdateStr = dateUpdate.format(formatter);

	        
	        String compteexist = String.format(
	            "{\"numCompte\": \"l2\", \"dateCreation\": \"%s\", \"dateUpdate\": \"%s\", \"devise\": \"devise\"}",
	            dateCreationStr, dateUpdateStr
	        );
		JsonObject expectedJsonObject = JsonParser.parseString(compteexist).getAsJsonObject();
        JsonObject actualJsonObject = JsonParser.parseString(compte1.toJson()).getAsJsonObject();
        assertEquals(expectedJsonObject, actualJsonObject);
	}
	
}
