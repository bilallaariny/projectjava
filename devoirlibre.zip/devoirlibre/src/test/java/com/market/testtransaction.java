package com.market;
import com.market.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

public class testtransaction {
@Test
public void recherchetransaction() {
	Transaction tr=new Transaction();
	tr.setReference("rf");
	Compte compte=new Compte();
	List<Transaction>transaction=new ArrayList<>();
	transaction.add(tr);
	compte.setTransaction(transaction);
	compte.recherchetransaction(tr);
}
}
