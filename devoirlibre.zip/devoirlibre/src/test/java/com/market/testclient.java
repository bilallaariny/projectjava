package com.market;
import com.market.LogBound;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.market.Client;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

public class testclient {
	@Test
	public void ajouteclienttest() {
		LogBound logbound=new LogBound();
		
		Client client=new Client("l2","3isam","laariny","minara","06","bilallaariny@");
		List<Client>list=new ArrayList<>();
		list.add(client);
		logbound.setClients(list);
		
		Client client1=new Client("l2","bilal","laariny","minara","06","bilallaariny@");
		logbound.ajouteclient(client1);
		for(Client c:logbound.getClients()) {
		System.out.print(c.getNom());
		}
		
	}
	@Test
	public void rechercheclienttest() {
LogBound logbound=new LogBound();
		
		Client client=new Client("l2","3isam","laariny","minara","06","bilallaariny@");
		List<Client>list=new ArrayList<>();
		list.add(client);
		logbound.setClients(list);
		
		Client client1=new Client("l1","3isam","laariny","minara","06","bilallaariny@");
		logbound.rechercheclient(client1);
		
	}
	@Test
	public void tojsontest() {
		Client client=new Client("l2","3isam","laariny","minara","06","bilallaariny@");
		System.out.print(client.toJson());
	String	clientexist="{\"numClient\": \"l1\", \"nom\": \"3isam\", \"prenom\": \"laariny\", \"adresse\": \"minara\", \"phone\": \"06\", \"email\": \"bilallaariny@\"}";
		System.out.print(clientexist);
		 JsonObject expectedJsonObject = JsonParser.parseString(clientexist).getAsJsonObject();
	        JsonObject actualJsonObject = JsonParser.parseString(client.toJson()).getAsJsonObject();
	        assertEquals(expectedJsonObject, actualJsonObject,"are the same");

	}

}
